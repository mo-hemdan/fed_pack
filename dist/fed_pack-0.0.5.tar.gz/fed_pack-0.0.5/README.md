# Fed_Pack Package

This is a package for federated learning . You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.